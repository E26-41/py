# -*- coding: utf-8 -*-

x = 'MODO'


def func_2():
    print('Call module_1.func_2() x =', x)
