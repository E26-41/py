# -*- coding: utf-8 -*-

variable_1 = 'Hello!'


def function1():
    print('Hey!')


print("Всем привет в этом чате!")

# print("Module name is", __name__)
