# -*- coding: utf-8 -*-

# Задача:
